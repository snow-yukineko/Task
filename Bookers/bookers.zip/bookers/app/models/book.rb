class Book < ApplicationRecord

end
