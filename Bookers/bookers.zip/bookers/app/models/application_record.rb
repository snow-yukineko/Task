class ApplicationRecord < ActiveRecord::Base
  self.abstract_class = true

  validates :Title, presence: true
  validates :Body, presence: true

end
