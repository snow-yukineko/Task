class BooksController < ApplicationController
  def new
  end

  def index
  end

  def show
  end

  def edit
  end
end
