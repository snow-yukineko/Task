class BooksController < ApplicationController
  def create
    book = Book.new(book_params)
    book.save
    redirect_to '/books'
  end

  def index
    @books = Book.all
    @book = Book.new
  end

  def show
    @book = Book.find(params[:id])
  end

  def edit
    @book = Book.find(params[:id])
  end

  def update
    book = Book.find(params[:id])
    if book.update(book_params)
      redirect_to book_path(book.id), notice: "Book was successfully updated."
    else
      render :new
    end
  end

  def destory
    book = Book.find(params[:id])
    book.destory
    redirect_to '/books'
  end

  private

  def book_params
    params.require(:book).permit(:"本のタイトル", :"感想")
  end
end
